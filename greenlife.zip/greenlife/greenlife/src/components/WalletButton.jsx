import { useState } from 'react';
import { ethers } from 'ethers';

const CONTRACT_ADDRESS = "0x6867858Ff16FE8992F4C68018a4Ad0C1Be300dA1";
const CONTRACT_ABI = [
  {
    "inputs": [],
    "name": "donate",
    "outputs": [],
    "stateMutability": "payable",
    "type": "function"
  }
];

const WalletButton = () => {
  const [currentAccount, setCurrentAccount] = useState(null);
  const [txStatus, setTxStatus] = useState('');

  const connectWallet = async () => {
    try {
      if (!window.ethereum) {
        alert("Установи MetaMask для подключения кошелька.");
        return;
      }
      const accounts = await window.ethereum.request({ method: 'eth_requestAccounts' });
      setCurrentAccount(accounts[0]);
    } catch (error) {
      console.error("Ошибка подключения кошелька:", error);
    }
  };

  const donate = async () => {
    try {
      if (!currentAccount) {
        alert("Сначала подключи кошелёк.");
        return;
      }

      const provider = new ethers.BrowserProvider(window.ethereum);
      const signer = await provider.getSigner();
      const contract = new ethers.Contract(CONTRACT_ADDRESS, CONTRACT_ABI, signer);

      const tx = await contract.donate({
        value: ethers.parseEther("0.01")
      });

      setTxStatus("⏳ Ожидание подтверждения транзакции...");
      await tx.wait();
      setTxStatus("✅ Пожертвование успешно отправлено!");

    } catch (error) {
      console.error("Ошибка при транзакции:", error);
      setTxStatus("❌ Ошибка при транзакции.");
    }
  };

  return (
    <div className="text-center mt-6">
      {!currentAccount ? (
        <button
          className="bg-green-600 text-white px-8 py-3 text-lg font-medium rounded-full shadow-md hover:bg-green-700 transition"
          onClick={connectWallet}
        >
          Подключить кошелёк
        </button>
      ) : (
        <button
          className="bg-yellow-500 text-white px-8 py-3 text-lg font-medium rounded-full shadow-md hover:bg-yellow-600 transition"
          onClick={donate}
        >
          Пожертвовать 0.01 ETH
        </button>
      )}
      {txStatus && <p className="mt-4 text-sm text-gray-700">{txStatus}</p>}
    </div>
  );
};

export default WalletButton;
