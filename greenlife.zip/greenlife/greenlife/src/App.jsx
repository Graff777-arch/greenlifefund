import WalletButton from './components/WalletButton';

function App() {
  return (
    <div className="min-h-screen bg-green-50 flex flex-col items-center justify-center px-4 text-center">
      <h1 className="text-5xl font-extrabold text-green-700 mb-4 drop-shadow-md">
        🌱 GreenLife
      </h1>
      <p className="mb-8 text-gray-600 text-lg max-w-md">
        Помоги озеленить Узбекистан — вноси вклад в посадку деревьев через наш смарт-контракт.
      </p>
      <WalletButton />
      <footer className="mt-16 text-sm text-gray-400">© 2025 GreenLife team</footer>
    </div>
  );
}

export default App;
