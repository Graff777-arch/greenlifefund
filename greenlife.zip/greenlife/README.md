# GreenLife Landing

Готовый статичный сайт для проекта GreenLife.

## Как запустить

1. Закиньте файлы на GitHub.
2. Подключите репозиторий к [Vercel](https://vercel.com) или [Netlify](https://netlify.com).
3. Готово! Сайт будет доступен по уникальному адресу.

## Структура

- index.html — основная страница
- styles.css — стили
